package _27571.Q4;

import java.util.Scanner;

public class MainProcurementApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {

            // Organization Info
            System.out.println("-------Organization Info(27571)-------");
            System.out.print("Organization Name: ");
            String orgName = sc.nextLine();
            System.out.print("Address: ");
            String address = sc.nextLine();
            System.out.print("Email: ");
            String email = sc.nextLine();

            // Department Info
            System.out.print("Department Name: ");
            String deptName = sc.nextLine();
            System.out.print("Department Code: ");
            String deptCode = sc.nextLine();

            // Supplier Info
            System.out.print("Supplier Name: ");
            String supplierName = sc.nextLine();
            System.out.print("Supplier TIN: ");
            String supplierTIN = sc.nextLine();
            System.out.print("Supplier Contact: ");
            String supplierContact = sc.nextLine();

            // Product Info
            System.out.print("Product Name: ");
            String productName = sc.nextLine();
            System.out.print("Unit Price: ");
            double unitPrice = Double.parseDouble(sc.nextLine());
            System.out.print("Quantity: ");
            int quantity = Integer.parseInt(sc.nextLine());

            // Purchase Order
            System.out.print("PO Number: ");
            String poNumber = sc.nextLine();
            System.out.print("Order Date (YYYY-MM-DD): ");
            String orderDate = sc.nextLine();
            double totalAmount = unitPrice * quantity;

            // Delivery
            System.out.print("Delivery Date (YYYY-MM-DD): ");
            String deliveryDate = sc.nextLine();
            System.out.print("Delivered By: ");
            String deliveredBy = sc.nextLine();

            // Inspection
            System.out.print("Inspector Name: ");
            String inspector = sc.nextLine();
            System.out.print("Inspection Status (Passed/Failed): ");
            String status = sc.nextLine();
            System.out.print("Inspection Remarks: ");
            String remarks = sc.nextLine();

            // Invoice (single)
            System.out.print("Invoice No: ");
            String invoiceNo = sc.nextLine();
            System.out.print("Invoice Amount: ");
            double invoiceAmount = Double.parseDouble(sc.nextLine());

            // Build ProcurementReport (uses all validations in constructors)
            ProcurementReport report = new ProcurementReport(1, "2025-01-01", "2025-01-01",
                    orgName, address, email,
                    deptName, deptCode,
                    supplierName, supplierTIN, supplierContact,
                    productName, unitPrice, quantity,
                    poNumber, orderDate, totalAmount,
                    deliveryDate, deliveredBy,
                    inspector, status, remarks,
                    invoiceNo, invoiceAmount,
                    java.time.LocalDate.now().toString(), "Auto-generated report");

            // Display summary & calculate total
            report.calculateTotal();

            System.out.println("\n--- END OF PROCUREMENT REPORT (27571) ---");

        } catch (IllegalArgumentException iae) {
            System.out.println("Validation error: " + iae.getMessage());
        } finally {
            sc.close();
        }
    }
}