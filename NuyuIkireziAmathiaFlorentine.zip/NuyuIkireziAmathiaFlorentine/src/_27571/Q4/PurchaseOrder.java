package _27571.Q4;

public class PurchaseOrder extends Product {
    private String poNumber;
    private String orderDate;
    private double totalAmount; // >0


    public PurchaseOrder(int id, String createdDate, String updatedDate,
                         String orgName, String address, String contactEmail,
                         String deptName, String deptCode,
                         String supplierName, String supplierTIN, String contact,
                         String productName, double unitPrice, int quantity,
                         String poNumber, String orderDate, double totalAmount) {
        super(id, createdDate, updatedDate, orgName, address, contactEmail, deptName, deptCode, supplierName, supplierTIN, contact, productName, unitPrice, quantity);
        if (poNumber == null || poNumber.isBlank()) throw new IllegalArgumentException("PO number required | ID: 27571");
        if (orderDate == null || orderDate.isBlank()) throw new IllegalArgumentException("Order date required | ID: 27571");
        if (totalAmount <= 0) throw new IllegalArgumentException("Total must be > 0 | ID: 27571");
        this.poNumber = poNumber;
        this.orderDate = orderDate;
        this.totalAmount = totalAmount;
    }


    public double getTotalAmount() { return totalAmount; }
}
