package _27571.Q4;

public class Supplier extends Department {
    private String supplierName;
    private String supplierTIN; // 9 digits
    private String contact; // phone 10 digits


    public Supplier(int id, String createdDate, String updatedDate,
                    String orgName, String address, String contactEmail,
                    String deptName, String deptCode,
                    String supplierName, String supplierTIN, String contact) {
        super(id, createdDate, updatedDate, orgName, address, contactEmail, deptName, deptCode);
        if (supplierName == null || supplierName.isBlank()) throw new IllegalArgumentException("Supplier name required | ID: 27571");
        if (supplierTIN == null || !supplierTIN.matches("\\d{9}")) throw new IllegalArgumentException("Supplier TIN must be 9 digits | ID: 27571");
        if (contact == null || !contact.matches("\\d{10}")) throw new IllegalArgumentException("Phone must be 10 digits | ID: 27571");
        this.supplierName = supplierName;
        this.supplierTIN = supplierTIN;
        this.contact = contact;
    }


    public String getSupplierName() { return supplierName; }
}
