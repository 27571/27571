package _27571.Q4;

public class Department extends Organization {
    private String deptName;
    private String deptCode; // alphanumeric >=3 chars


    public Department(int id, String createdDate, String updatedDate,
                      String orgName, String address, String contactEmail,
                      String deptName, String deptCode) {
        super(id, createdDate, updatedDate, orgName, address, contactEmail);
        if (deptCode == null || deptCode.length() < 3 || !deptCode.matches("[A-Za-z0-9]+"))
            throw new IllegalArgumentException("Dept code must be alphanumeric and >=3 chars | ID: 27571");
        if (deptName == null || deptName.isBlank()) throw new IllegalArgumentException("Dept name required | ID: 27571");
        this.deptName = deptName;
        this.deptCode = deptCode;
    }


    public String getDeptName() { return deptName; }
}
