package _27571.Q4;

public class Organization extends Entity {
    private String orgName;
    private String address;
    private String contactEmail;


    public Organization(int id, String createdDate, String updatedDate,
                        String orgName, String address, String contactEmail) {
        super(id, createdDate, updatedDate);
        if (orgName == null || orgName.isBlank()) throw new IllegalArgumentException("Org name required | ID: 27571");
        if (address == null || address.isBlank()) throw new IllegalArgumentException("Address required | ID: 27571");
        if (contactEmail == null || !contactEmail.matches("^\\S+@\\S+\\.\\S+$")) throw new IllegalArgumentException("Invalid email | ID: 27571");
        this.orgName = orgName;
        this.address = address;
        this.contactEmail = contactEmail;
    }


    public String getOrgName() { return orgName; }
}
