package _27571.Q4;

public class Inspection extends Delivery {
    private String inspectorName;
    private String status; // Passed/Failed
    private String remarks;


    public Inspection(int id, String createdDate, String updatedDate,
                      String orgName, String address, String contactEmail,
                      String deptName, String deptCode,
                      String supplierName, String supplierTIN, String contact,
                      String productName, double unitPrice, int quantity,
                      String poNumber, String orderDate, double totalAmount,
                      String deliveryDate, String deliveredBy,
                      String inspectorName, String status, String remarks) {
        super(id, createdDate, updatedDate, orgName, address, contactEmail, deptName, deptCode, supplierName, supplierTIN, contact, productName, unitPrice, quantity, poNumber, orderDate, totalAmount, deliveryDate, deliveredBy);
        if (inspectorName == null || inspectorName.isBlank()) throw new IllegalArgumentException("Inspector name required | ID: 27571");
        if (!"Passed".equalsIgnoreCase(status) && !"Failed".equalsIgnoreCase(status)) throw new IllegalArgumentException("Status must be Passed or Failed | ID: 27571");
        this.inspectorName = inspectorName;
        this.status = status;
        this.remarks = remarks;
    }


    public String getStatus() { return status; }
}
