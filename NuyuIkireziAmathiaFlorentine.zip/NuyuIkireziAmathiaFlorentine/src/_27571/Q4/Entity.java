package _27571.Q4;

public class Entity {
    private int id;
    private String createdDate;
    private String updatedDate;


    public Entity(int id, String createdDate, String updatedDate) {
        if (id <= 0) throw new IllegalArgumentException("ID must be > 0 | ID: 27571");
        if (createdDate == null || createdDate.isBlank() || updatedDate == null || updatedDate.isBlank())
            throw new IllegalArgumentException("Dates must not be null or empty | ID: 27571");
        this.id = id;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }


    public int getId() { return id; }
    public String getCreatedDate() { return createdDate; }
    public String getUpdatedDate() { return updatedDate; }
}
