package _27571.Q4;

public final class ProcurementReport extends Invoice {
    private String reportDate;
    private String summary;


    public ProcurementReport(int id, String createdDate, String updatedDate,
                             String orgName, String address, String contactEmail,
                             String deptName, String deptCode,
                             String supplierName, String supplierTIN, String contact,
                             String productName, double unitPrice, int quantity,
                             String poNumber, String orderDate, double totalAmount,
                             String deliveryDate, String deliveredBy,
                             String inspectorName, String status, String remarks,
                             String invoiceNo, double invoiceAmount,
                             String reportDate, String summary) {
        super(id, createdDate, updatedDate, orgName, address, contactEmail, deptName, deptCode, supplierName, supplierTIN, contact, productName, unitPrice, quantity, poNumber, orderDate, totalAmount, deliveryDate, deliveredBy, inspectorName, status, remarks, invoiceNo, invoiceAmount);
        this.reportDate = reportDate;
        this.summary = summary;
    }


    // calculateTotal = sum of all invoice amounts (here single invoice) -> return invoiceAmount
    public double calculateTotal() {
        double total = getInvoiceAmount();
        System.out.println("\n===== PROCUREMENT REPORT ===== | ID: 27571");
        System.out.println("Report Date: " + reportDate + " | ID: 27571");
        System.out.println("Invoice No: " + getInvoiceNo() + " | ID: 27571");
        System.out.println("Invoice Amount: " + getInvoiceAmount() + " | ID: 27571");
        System.out.println("Summary: " + summary + " | ID: 27571");
        System.out.println("Total Purchase Amount: " + total + " | ID: 27571");
        return total;
    }
}
