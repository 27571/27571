package _27571.Q4;

public class Product extends Supplier {
    private String productName;
    private double unitPrice; // >0
    private int quantity; // >=0


    public Product(int id, String createdDate, String updatedDate,
                   String orgName, String address, String contactEmail,
                   String deptName, String deptCode,
                   String supplierName, String supplierTIN, String contact,
                   String productName, double unitPrice, int quantity) {
        super(id, createdDate, updatedDate, orgName, address, contactEmail, deptName, deptCode, supplierName, supplierTIN, contact);
        if (productName == null || productName.isBlank()) throw new IllegalArgumentException("Product name required | ID: 27571");
        if (unitPrice <= 0) throw new IllegalArgumentException("Unit price must be > 0 | ID: 27571");
        if (quantity < 0) throw new IllegalArgumentException("Quantity must be >= 0 | ID: 27571");
        this.productName = productName;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
    }


    public double getUnitPrice() { return unitPrice; }
    public int getQuantity() { return quantity; }
    public String getProductName() { return productName; }
}
