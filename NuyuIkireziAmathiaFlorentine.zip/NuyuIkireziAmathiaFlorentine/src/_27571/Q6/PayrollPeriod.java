package _27571.Q6;

import java.util.Date;

class PayrollPeriod extends Employee {
    private int month;
    private int year;
    private Date startDate;
    private Date endDate;


    public PayrollPeriod(int id, String orgName, String orgCode, String rssbNumber, String contactEmail,
                         String deptName, String deptCode, String managerName,
                         int employeeID, String fullName, String position, double baseSalary, boolean rssbRegistered,
                         int month, int year, Date startDate, Date endDate) {
        super(id, orgName, orgCode,
                employeeID, fullName, position, baseSalary, rssbRegistered);
        if (month < 1 || month > 12) throw new IllegalArgumentException("Month invalid");
        if (year < 2000) throw new IllegalArgumentException("Year invalid");
        this.month = month;
        this.year = year;
        this.startDate = startDate;
        this.endDate = endDate;
    }


    public int getMonth() { return month; }
    public int getYear() { return year; }
    public Date getStartDate() { return startDate; }
    public Date getEndDate() { return endDate; }
}
