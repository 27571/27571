package _27571.Q6;


import java.util.Scanner;

public class PayrollMain {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("===== PAYROLL MANAGEMENT SYSTEM (RSSB) 27571 =====");

        // -------- EMPLOYEE --------
        System.out.print("Employee ID (>=1000): ");
        int empID = sc.nextInt();
        sc.nextLine(); // fix buffer

        System.out.print("Employee Full Name: ");
        String empName = sc.nextLine();

        System.out.print("Position: ");
        String position = sc.nextLine();

        System.out.print("Base Salary (>0): ");
        double baseSalary = sc.nextDouble();

        System.out.print("RSSB Registered (true/false): ");
        boolean registered = sc.nextBoolean();

        Employee emp = new Employee(3, "2025-01-01", "2025-01-01",
                empID, empName, position, baseSalary, registered);

        // -------- SALARY STRUCTURE --------
        System.out.print("Basic Pay: ");
        double basic = sc.nextDouble();

        System.out.print("Transport Allowance: ");
        double transport = sc.nextDouble();

        System.out.print("Housing Allowance: ");
        double housing = sc.nextDouble();

        SalaryStructure ss = new SalaryStructure(4, "2025-01-01",
                "2025-01-01", basic, transport, housing);

        // -------- ALLOWANCE --------
        System.out.print("Overtime Hours: ");
        int otHours = sc.nextInt();

        System.out.print("Overtime Rate: ");
        double otRate = sc.nextDouble();

        System.out.print("Bonus: ");
        double bonus = sc.nextDouble();

        Allowance al = new Allowance(5, "2025-01-01", "2025-01-01", otHours, otRate, bonus);

        // -------- DEDUCTIONS --------
        System.out.print("PAYE Tax: ");
        double paye = sc.nextDouble();

        System.out.print("Loan Deduction: ");
        double loan = sc.nextDouble();

        Deduction ded = new Deduction(6, "2025-01-01",
                "2025-01-01", ss.getBasicPay(), paye, loan);

        // -------- PAYROLL --------
        Payroll payroll = new Payroll(
                otHours, otRate);

        // -------- PAYSLIP --------
        Payslip slip = new Payslip(8, "2025-01-01",
                "PS-001", "2025-01-01", payroll, otHours, otRate);

        slip.generatePayslip();

        System.out.println("\n--- END OF PAYROLL REPORT 27571 ---");
    }
}
