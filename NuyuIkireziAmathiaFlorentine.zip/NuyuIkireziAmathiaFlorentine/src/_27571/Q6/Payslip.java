package _27571.Q6;

import java.util.Date;

final class Payslip extends Payroll {
    private String payslipNumber;
    private Date issueDate;


    public Payslip(int id, String orgName, String orgCode, String rssbNumber, String contactEmail,
                   String deptName, String deptCode, String managerName,
                   int employeeID, String fullName, String position, double baseSalary, boolean rssbRegistered,
                   int month, int year, Date startDate, Date endDate,
                   double basicPay, double transportAllowance, double housingAllowance,
                   double payeTax, double loanDeduction,
                   double overtimeHours, double overtimeRate, double bonus,
                   String payslipNumber, Date issueDate, int otHours, double otRate) {
        super(id, orgName, orgCode, rssbNumber, contactEmail, deptName, deptCode, managerName,
                employeeID, fullName, position, baseSalary, rssbRegistered, month, year, startDate, endDate,
                basicPay, transportAllowance, housingAllowance, payeTax, loanDeduction, overtimeHours, overtimeRate, bonus, otHours, otRate);
        this.payslipNumber = payslipNumber;
        this.issueDate = issueDate;
    }

    public Payslip(int id, String date, String orgCode, String date1, Payroll payroll, int otHours, double otRate) {
        super(otHours, otRate);
    }


    public void generatePayslip() {
        System.out.println("\n===== PAYSLIP ===== 27571");
        System.out.println("Payslip Number: " + payslipNumber + " | ID: 27571");
        System.out.println("Issue Date: " + issueDate + " | ID: 27571");
        System.out.println("Employee: " + getFullName() + " | ID: 27571");
        System.out.println("Position: " + getPosition() + " | ID: 27571");
        System.out.println("Gross Salary: " + getGrossSalary() + " | ID: 27571");
        System.out.println("Total Deductions: " + getTotalDeductions() + " | ID: 27571");
        System.out.println("Net Salary: " + getNetSalary() + " | ID: 27571");
    }
}