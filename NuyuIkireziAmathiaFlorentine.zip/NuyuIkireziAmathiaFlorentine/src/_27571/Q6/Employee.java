package _27571.Q6;

class Employee extends Department {
    public static String managerName;
    protected static String deptCode;
    protected static String deptName;
    protected static String contactEmail;
    protected static String rssbNumber;
    private int employeeID;
    private String fullName;
    private String position;
    private double baseSalary;
    private boolean rssbRegistered;


    public Employee(int id, String orgName, String orgCode,
                    int employeeID, String fullName, String position, double baseSalary, boolean rssbRegistered) {
        super(id, orgName, orgCode, rssbNumber, contactEmail, deptName, deptCode, managerName);
        if (employeeID < 1000) throw new IllegalArgumentException("Employee ID >= 1000");
        if (baseSalary <= 0) throw new IllegalArgumentException("Base salary > 0");
        this.employeeID = employeeID;
        this.fullName = fullName;
        this.position = position;
        this.baseSalary = baseSalary;
        this.rssbRegistered = rssbRegistered;
    }


    public int getEmployeeID() {
        return employeeID;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPosition() {
        return position;
    }

    public double getBaseSalary() {
        return baseSalary;
    }

    public boolean isRssbRegistered() {
        return rssbRegistered;
    }
}
