package _27571.Q6;

class Allowance extends Deduction {
    private static double baseSalary;
    private static double basicPay ;
    private static double transportAllowance;
    private static String orgCode;
    private static String orgName;
    private static int id ;
    private double overtimeHours;
    private double overtimeRate;
    private double bonus;


    public Allowance(int i, String date, String s, int otHours, double otRate, double bonus) {
        super(id, orgName, orgCode,
                baseSalary,
                basicPay, transportAllowance);
        if (overtimeHours < 0 || overtimeRate < 0 || this.bonus < 0) throw new IllegalArgumentException("Allowance >= 0");
        this.overtimeHours = overtimeHours;
        this.overtimeRate = overtimeRate;
        this.bonus = this.bonus;
    }


    public double getOvertimeHours() { return overtimeHours; }
    public double getOvertimeRate() { return overtimeRate; }
    public double getBonus() { return bonus; }
}
