package _27571.Q6;

import java.util.Date;

class Payroll extends Allowance {
    private static double bonus;
    private double grossSalary;
    private double totalDeductions;
    private double netSalary;


    public Payroll(int id, String orgName, String orgCode, String rssbNumber, String contactEmail,
                   String deptName, String deptCode, String managerName,
                   int employeeID, String fullName, String position, double baseSalary, boolean rssbRegistered,
                   int month, int year, Date startDate, Date endDate,
                   double basicPay, double transportAllowance, double housingAllowance,
                   double payeTax, double loanDeduction,
                   double overtimeHours, double overtimeRate, double bonus, int otHours, double otRate) {
        super(
                5, "2025-01-01", "2025-01-01", otHours, otRate, bonus);
        this.grossSalary = getBasicPay() + getTransportAllowance() + getHousingAllowance() + (overtimeHours*overtimeRate) + bonus;
        this.totalDeductions = getRssbContribution() + getPayeTax() + getLoanDeduction();
        this.netSalary = grossSalary - totalDeductions;
    }

    public Payroll(int otHours, double otRate) {
        super(5, "2025-01-01", "2025-01-01", otHours, otRate, bonus);
    }


    public double getGrossSalary() { return grossSalary; }
    public double getTotalDeductions() { return totalDeductions; }
    public double getNetSalary() { return netSalary; }
}
