package _27571.Q6;

class Organization extends Entity {
    private String orgName;
    private String orgCode;
    private String rssbNumber;
    private String contactEmail;


    public Organization(int id, String orgName, String orgCode, String rssbNumber, String contactEmail) {
        super(id);
        if (orgCode.length() < 3) throw new IllegalArgumentException("OrgCode >= 3 chars");
        if (!rssbNumber.matches("\\d{8}")) throw new IllegalArgumentException("RSSB Number must be 8 digits");
        if (!contactEmail.contains("@")) throw new IllegalArgumentException("Invalid email");
        this.orgName = orgName;
        this.orgCode = orgCode;
        this.rssbNumber = rssbNumber;
        this.contactEmail = contactEmail;
    }


    public String getOrgName() { return orgName; }
    public String getOrgCode() { return orgCode; }
    public String getRssbNumber() { return rssbNumber; }
    public String getContactEmail() { return contactEmail; }
}
