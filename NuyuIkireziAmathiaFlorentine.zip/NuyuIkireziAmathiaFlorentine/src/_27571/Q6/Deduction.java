package _27571.Q6;

class Deduction extends SalaryStructure {
    private double rssbContribution;
    private double payeTax;
    private double loanDeduction;


    public Deduction(int id, String orgName, String orgCode,
                     double baseSalary,
                     double basicPay, double transportAllowance) {
        super(id, orgName, orgCode,
                baseSalary,
                basicPay, transportAllowance);
        this.rssbContribution = basicPay * 0.05;
        this.payeTax = payeTax;
        this.loanDeduction = loanDeduction;
    }


    public double getRssbContribution() { return rssbContribution; }
    public double getPayeTax() { return payeTax; }
    public double getLoanDeduction() { return loanDeduction; }
}
