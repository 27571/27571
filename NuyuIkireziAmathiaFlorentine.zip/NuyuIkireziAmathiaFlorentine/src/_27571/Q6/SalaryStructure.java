package _27571.Q6;

import java.util.Date;

class SalaryStructure extends PayrollPeriod {
    private static Date endDate;
    private static Date startDate;
    private static int year ;
    private static int month;
    private static boolean rssbRegistered ;
    private static String position ;
    private static String fullName;
    private static int employeeID ;
    private double basicPay;
    private double transportAllowance;
    private double housingAllowance;


    public SalaryStructure(int id, String orgName, String orgCode,
                           double baseSalary,
                           double basicPay, double transportAllowance) {
        super(id, orgName, orgCode, rssbNumber, contactEmail, deptName, deptCode, managerName,
                employeeID, fullName, position, baseSalary, rssbRegistered, month, year, startDate, endDate);
        if (basicPay < 0 || transportAllowance < 0 || housingAllowance < 0)
            throw new IllegalArgumentException("Salary components >= 0");
        this.basicPay = basicPay;
        this.transportAllowance = transportAllowance;
        this.housingAllowance = housingAllowance;
    }


    public double getBasicPay() { return basicPay; }
    public double getTransportAllowance() { return transportAllowance; }
    public double getHousingAllowance() { return housingAllowance; }
}
