package _27571.Q6;

import java.util.Date;

class Entity {
    private int id;
    private Date createdDate;
    private Date updatedDate;


    public Entity(int id) {
        if (id <= 0) throw new IllegalArgumentException("ID must be > 0");
        this.id = id;
        this.createdDate = new Date();
        this.updatedDate = new Date();
    }


    public int getId() { return id; }
    public Date getCreatedDate() { return createdDate; }
    public Date getUpdatedDate() { return updatedDate; }
}
