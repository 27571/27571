package _27571.Q6;

public class Department extends Organization {
    private String deptName;
    private String deptCode;
    private String managerName;


    public Department(int id, String orgName, String orgCode, String rssbNumber, String contactEmail,
                      String deptName, String deptCode, String managerName) {
        super(id, orgName, orgCode, rssbNumber, contactEmail);
        if (deptCode.length() < 3) throw new IllegalArgumentException("DeptCode >=3 chars");
        this.deptName = deptName;
        this.deptCode = deptCode;
        this.managerName = managerName;
    }


    public String getDeptName() { return deptName; }
    public String getDeptCode() { return deptCode; }
    public String getManagerName() { return managerName; }
}
