package _27571.Q5;

public class Student {
    private String studentName;
    private String studentID;
    private int age;

    public Student(int id, String createdDate, String updatedDate,
                   String institutionName, String code, String address,
                   String departmentName, String departmentHead,
                   String courseName, String courseCode, int credits,
                   String instructorName, String email, String phone,
                   String studentName, String studentID, int age) {
        super();
        if (age <= 0) {
            throw new IllegalArgumentException("Age must be greater than 0");
        }
        this.studentName = studentName;
        this.studentID = studentID;
        this.age = age;
    }

    // Getters and Setters
    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age <= 0) {
            throw new IllegalArgumentException("Age must be greater than 0");
        }
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student [" + super.toString() +
                ", Name=" + studentName + ", ID=" + studentID +
                ", Age=" + age + "]";
    }
}
