package _27571.Q5;

class Institution extends Entity {
    private String institutionName;
    private String code;
    private String address;

    public Institution(int id, String createdDate, String updatedDate,
                       String institutionName, String code, String address) {
        super(id, createdDate, updatedDate);
        if (code == null || code.length() < 3) {
            throw new IllegalArgumentException("Code must be at least 3 characters");
        }
        this.institutionName = institutionName;
        this.code = code;
        this.address = address;
    }

    // Getters and Setters
    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        if (code == null || code.length() < 3) {
            throw new IllegalArgumentException("Code must be at least 3 characters");
        }
        this.code = code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Institution [" + super.toString() +
                ", Name=" + institutionName + ", Code=" + code +
                ", Address=" + address + "]";
    }
}
