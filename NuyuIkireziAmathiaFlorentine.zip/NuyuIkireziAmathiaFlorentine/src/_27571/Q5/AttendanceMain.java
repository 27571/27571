package _27571.Q5;

import java.time.LocalDate;
import java.util.Scanner;

/**
 * Main class to run the Attendance Management System
 */
class AttendanceMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("=== ATTENDANCE MANAGEMENT SYSTEM || 27571 ===\n");

            // Entity & Institution
            System.out.print("Enter Entity ID: ");
            int id = Integer.parseInt(sc.nextLine());
            String createdDate = LocalDate.now().toString();
            String updatedDate = LocalDate.now().toString();

            System.out.print("Institution Name: ");
            String institutionName = sc.nextLine();
            System.out.print("Institution Code (min 3 chars): ");
            String instCode = sc.nextLine();
            System.out.print("Institution Address: ");
            String address = sc.nextLine();

            // Department
            System.out.print("Department Name: ");
            String deptName = sc.nextLine();
            System.out.print("Department Head: ");
            String deptHead = sc.nextLine();

            // Course
            System.out.print("Course Name: ");
            String courseName = sc.nextLine();
            System.out.print("Course Code: ");
            String courseCode = sc.nextLine();
            System.out.print("Credits (must be > 0): ");
            int credits = Integer.parseInt(sc.nextLine());

            // Instructor
            System.out.print("Instructor Name: ");
            String instructorName = sc.nextLine();
            System.out.print("Instructor Email: ");
            String email = sc.nextLine();
            System.out.print("Instructor Phone (10 digits): ");
            String phone = sc.nextLine();

            // Student
            System.out.print("Student Name: ");
            String studentName = sc.nextLine();
            System.out.print("Student ID: ");
            String studentID = sc.nextLine();
            System.out.print("Student Age: ");
            int age = Integer.parseInt(sc.nextLine());

            // Class Session
            System.out.print("Session Date (YYYY-MM-DD): ");
            String sessionDate = sc.nextLine();
            System.out.print("Session Topic: ");
            String topic = sc.nextLine();

            // Attendance Record
            System.out.print("Session ID: ");
            int sessionID = Integer.parseInt(sc.nextLine());
            System.out.print("Attendance Status (Present/Absent): ");
            String status = sc.nextLine();

            // Leave Request
            System.out.print("Leave Request Date (YYYY-MM-DD): ");
            String requestDate = sc.nextLine();
            System.out.print("Leave Reason: ");
            String reason = sc.nextLine();
            System.out.print("Is Leave Approved? (true/false): ");
            boolean approved = Boolean.parseBoolean(sc.nextLine());

            // Attendance Summary
            System.out.print("Total Present Days: ");
            int totalPresent = Integer.parseInt(sc.nextLine());
            System.out.print("Total Absent Days: ");
            int totalAbsent = Integer.parseInt(sc.nextLine());

            // Create AttendanceSummary object
            AttendanceSummary summary = new AttendanceSummary(
                    id, createdDate, updatedDate,
                    institutionName, instCode, address,
                    deptName, deptHead,
                    courseName, courseCode, credits,
                    instructorName, email, phone,
                    studentName, studentID, age,
                    sessionDate, topic,
                    studentID, sessionID, status,
                    requestDate, reason, approved,
                    LocalDate.now().toString(), totalPresent, totalAbsent
            );

            // Display summary
            summary.displaySummary();

        } catch (IllegalArgumentException e) {
            System.out.println("Validation Error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}

