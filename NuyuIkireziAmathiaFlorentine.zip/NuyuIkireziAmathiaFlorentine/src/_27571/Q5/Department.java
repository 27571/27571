package _27571.Q5;

public class Department {
    private String departmentName;
    private String departmentHead;

    public Department(int id, String createdDate, String updatedDate,
                      String institutionName, String code, String address,
                      String departmentName, String departmentHead) {
        super();
        if (departmentName == null || departmentName.trim().isEmpty()) {
            throw new IllegalArgumentException("Department name cannot be empty");
        }
        if (departmentHead == null || departmentHead.trim().isEmpty()) {
            throw new IllegalArgumentException("Department head cannot be empty");
        }
        this.departmentName = departmentName;
        this.departmentHead = departmentHead;
    }

    // Getters and Setters
    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        if (departmentName == null || departmentName.trim().isEmpty()) {
            throw new IllegalArgumentException("Department name cannot be empty");
        }
        this.departmentName = departmentName;
    }

    public String getDepartmentHead() {
        return departmentHead;
    }

    public void setDepartmentHead(String departmentHead) {
        if (departmentHead == null || departmentHead.trim().isEmpty()) {
            throw new IllegalArgumentException("Department head cannot be empty");
        }
        this.departmentHead = departmentHead;
    }

    @Override
    public String toString() {
        return "Department [" + super.toString() +
                ", Name=" + departmentName + ", Head=" + departmentHead + "]";
    }
}

