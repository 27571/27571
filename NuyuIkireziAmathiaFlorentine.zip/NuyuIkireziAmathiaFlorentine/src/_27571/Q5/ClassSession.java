package _27571.Q5;

public class ClassSession {
    private String sessionDate;
    private String topic;

    public ClassSession(int id, String createdDate, String updatedDate,
                        String institutionName, String code, String address,
                        String departmentName, String departmentHead,
                        String courseName, String courseCode, int credits,
                        String instructorName, String email, String phone,
                        String studentName, String studentID, int age,
                        String sessionDate, String topic) {
        super();
        if (sessionDate == null) {
            throw new IllegalArgumentException("Session date cannot be null");
        }
        if (topic == null) {
            throw new IllegalArgumentException("Topic cannot be null");
        }
        this.sessionDate = sessionDate;
        this.topic = topic;
    }

    // Getters and Setters
    public String getSessionDate() {
        return sessionDate;
    }

    public void setSessionDate(String sessionDate) {
        if (sessionDate == null) {
            throw new IllegalArgumentException("Session date cannot be null");
        }
        this.sessionDate = sessionDate;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        if (topic == null) {
            throw new IllegalArgumentException("Topic cannot be null");
        }
        this.topic = topic;
    }

    @Override
    public String toString() {
        return "ClassSession [" + super.toString() +
                ", Date=" + sessionDate + ", Topic=" + topic + "]";
    }
}
