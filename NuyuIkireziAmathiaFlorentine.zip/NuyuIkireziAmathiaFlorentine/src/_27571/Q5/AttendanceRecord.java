package _27571.Q5;

public class AttendanceRecord {
    private String recordStudentID;
    private int sessionID;
    private String status;

    public AttendanceRecord(int id, String createdDate, String updatedDate,
                            String institutionName, String code, String address,
                            String departmentName, String departmentHead,
                            String courseName, String courseCode, int credits,
                            String instructorName, String email, String phone,
                            String studentName, String studentID, int age,
                            String sessionDate, String topic,
                            String recordStudentID, int sessionID, String status) {
        super();
        if (!status.equals("Present") && !status.equals("Absent")) {
            throw new IllegalArgumentException("Status must be 'Present' or 'Absent'");
        }
        this.recordStudentID = recordStudentID;
        this.sessionID = sessionID;
        this.status = status;
    }

    // Getters and Setters
    public String getRecordStudentID() {
        return recordStudentID;
    }

    public void setRecordStudentID(String recordStudentID) {
        this.recordStudentID = recordStudentID;
    }

    public int getSessionID() {
        return sessionID;
    }

    public void setSessionID(int sessionID) {
        this.sessionID = sessionID;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        if (!status.equals("Present") && !status.equals("Absent")) {
            throw new IllegalArgumentException("Status must be 'Present' or 'Absent'");
        }
        this.status = status;
    }

    @Override
    public String toString() {
        return "AttendanceRecord [" + super.toString() +
                ", StudentID=" + recordStudentID + ", SessionID=" + sessionID +
                ", Status=" + status + "]";
    }
}
