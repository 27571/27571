package _27571.Q5;

public class LeaveRequest {
    private String requestDate;
    private String reason;
    private boolean approved;
    private Object getCourseCode;

    public LeaveRequest(int id, String createdDate, String updatedDate,
                        String institutionName, String code, String address,
                        String departmentName, String departmentHead,
                        String courseName, String courseCode, int credits,
                        String instructorName, String email, String phone,
                        String studentName, String studentID, int age,
                        String sessionDate, String topic,
                        String recordStudentID, int sessionID, String status,
                        String requestDate, String reason, boolean approved) {
        super();
        if (reason == null || reason.trim().isEmpty()) {
            throw new IllegalArgumentException("Reason cannot be empty");
        }
        this.requestDate = requestDate;
        this.reason = reason;
        this.approved = approved;
    }

    // Getters and Setters
    public String getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        if (reason == null || reason.trim().isEmpty()) {
            throw new IllegalArgumentException("Reason cannot be empty");
        }
        this.reason = reason;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    @Override
    public String toString() {
        return "LeaveRequest [" + super.toString() +
                ", RequestDate=" + requestDate + ", Reason=" + reason +
                ", Approved=" + approved + "]";
    }

    public String getStudentName() {
        String studentName = "";
        return studentName;
    }

    public String getStudentID() {
        String studentID="";
        return studentID;
    }

    public String getCourseName() {
        String courseName="";
        return courseName;
    }
    public String getCourseCode() {
        String CourseCode="";
        return getCourseCode();
    }
    public String getInstructorName() {
        String instructorName="";
        return instructorName;
    }

}
