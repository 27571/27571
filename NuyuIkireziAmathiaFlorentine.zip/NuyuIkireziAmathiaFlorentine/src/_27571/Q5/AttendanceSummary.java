package _27571.Q5;

import _27571.Q5.LeaveRequest;
import _27571.Q5.Student;

final class AttendanceSummary extends LeaveRequest {
    private String reportDate;
    private int totalPresent;
    private int totalAbsent;

    public AttendanceSummary(int id, String createdDate, String updatedDate,
                             String institutionName, String code, String address,
                             String departmentName, String departmentHead,
                             String courseName, String courseCode, int credits,
                             String instructorName, String email, String phone,
                             String studentName, String studentID, int age,
                             String sessionDate, String topic,
                             String recordStudentID, int sessionID, String status,
                             String requestDate, String reason, boolean approved,
                             String rDate, int tPresent, int tAbsent) {
        super(id, createdDate, updatedDate, institutionName, code, address,
                departmentName, departmentHead, courseName, courseCode, credits,
                instructorName, email, phone, studentName, studentID, age,
                sessionDate, topic, recordStudentID, sessionID, status,
                requestDate, reason, approved);
        this.reportDate = rDate;
        this.totalPresent = tPresent;
        this.totalAbsent = tAbsent;
    }

    /**
     * Generates attendance summary percentage
     * Formula: (totalPresent / totalSessions) × 100
     * @return attendance percentage
     */
    public double generateSummary() {
        int totalSessions = totalPresent + totalAbsent;
        if (totalSessions == 0) {
            return 0.0;
        }
        return (totalPresent * 100.0) / totalSessions;
    }

    // Getters and Setters
    public String getReportDate() {
        return reportDate;
    }

    public void setReportDate(String reportDate) {
        this.reportDate = reportDate;
    }

    public int getTotalPresent() {
        return totalPresent;
    }

    public void setTotalPresent(int totalPresent) {
        this.totalPresent = totalPresent;
    }

    public int getTotalAbsent() {
        return totalAbsent;
    }

    public void setTotalAbsent(int totalAbsent) {
        this.totalAbsent = totalAbsent;
    }

    public void displaySummary() {
        System.out.println("\n=== ATTENDANCE SUMMARY REPORT ===");
        System.out.println("Report Date: " + reportDate);
        System.out.println("Student Name: " + super.getStudentName());
        System.out.println("Student ID: " + super.getStudentID());
        System.out.println("Course: " + super.getCourseName() + " (" + super.getCourseCode() + ")");
        System.out.println("Instructor: " + super.getInstructorName());
        System.out.println("--------------------------------");
        System.out.println("Total Sessions: " + (totalPresent + totalAbsent));
        System.out.println("Present: " + totalPresent);
        System.out.println("Absent: " + totalAbsent);
        System.out.printf("Attendance Percentage: %.2f%%\n", generateSummary());
        System.out.println("================================\n");
    }

    @Override
    public String toString() {
        return "AttendanceSummary [" + super.toString() +
                ", ReportDate=" + reportDate + ", Present=" + totalPresent +
                ", Absent=" + totalAbsent + ", Percentage=" +
                String.format("%.2f%%", generateSummary()) + "]";
    }}