package _27571.Q3;


public class Employee extends Entity {
    private String employeeName;
    private double salary;
    private String employeeTIN;

    public Employee(int id, String cd, String ud,
                    String name, double salary, String tin) throws TaxDataException {
        super(id, cd, ud);

        if (salary <= 0) throw new TaxDataException("Salary must be > 0");
        if (tin.length() != 9) throw new TaxDataException("Employee TIN invalid");

        this.employeeName = name;
        this.salary = salary;
        this.employeeTIN = tin;
    }

    public double getSalary() { return salary; }
}

