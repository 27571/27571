package _27571.Q3;


public class TaxDeclaration extends Entity {
    private String declarationMonth;
    private double totalIncome;

    public TaxDeclaration(int id, String cd, String ud,
                          String month, double income) throws TaxDataException {
        super(id, cd, ud);

        if (income < 0) throw new TaxDataException("Income cannot be negative");

        this.declarationMonth = month;
        this.totalIncome = income;
    }

    public double getTotalIncome() { return totalIncome; }
}

