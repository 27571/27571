package _27571.Q3;

import java.util.Scanner;

public class MainTaxSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("==== TAX ADMINISTRATION SYSTEM | ID: 27571 ====");

            System.out.print("Enter Employee Name: ");
            String empName = sc.nextLine();

            System.out.print("Enter Employee Salary: ");
            double salary = sc.nextDouble();

            System.out.print("Enter Employee TIN (9 digits): ");
            String tin = sc.next();

            Employee emp = new Employee(1, "2025-01-01", "2025-01-01",
                    empName, salary, tin);

            TaxCategory cat = new TaxCategory(2, "2025-01-01", "2025-01-01",
                    "Income Tax", 0.2, "TX1");

            System.out.print("Enter Tax Credit: ");
            double credit = sc.nextDouble();

            TaxRecord record = new TaxRecord(3, "2025-01-01", "2025-01-01",
                    "RC-001", emp, cat);

            double payable = record.computeTax(credit);

            System.out.println("\n=== RESULT | ID: 27571 ===");
            System.out.println("Employee: " + empName + " | ID: 27571");
            System.out.println("Salary: " + salary + " | ID: 27571");
            System.out.println("Tax Rate: " + cat.getRate() + " | ID: 27571");
            System.out.println("Credits: " + credit + " | ID: 27571");
            System.out.println("Total Payable Tax: " + payable + " | ID: 27571");

        } catch (TaxDataException e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
}

