package _27571.Q3;


public class TaxAssessment extends Entity {
    private String assessmentDate;
    private double assessedTax;

    public TaxAssessment(int id, String cd, String ud,
                         String date, double tax) throws TaxDataException {
        super(id, cd, ud);

        if (tax < 0) throw new TaxDataException("Tax cannot be negative");

        this.assessmentDate = date;
        this.assessedTax = tax;
    }
}
