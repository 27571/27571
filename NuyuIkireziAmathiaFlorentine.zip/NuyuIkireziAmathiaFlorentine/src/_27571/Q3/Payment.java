package _27571.Q3;


public class Payment extends Entity {
    private String paymentDate;
    private double paymentAmount;

    public Payment(int id, String cd, String ud,
                   String date, double amount) throws TaxDataException {
        super(id, cd, ud);

        if (amount <= 0) throw new TaxDataException("Payment must be > 0");

        this.paymentDate = date;
        this.paymentAmount = amount;
    }

    public double getPaymentAmount() { return paymentAmount; }
}
