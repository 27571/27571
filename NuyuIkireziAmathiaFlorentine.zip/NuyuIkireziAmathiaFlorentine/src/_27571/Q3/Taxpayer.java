package _27571.Q3;

public class Taxpayer extends Entity {
    private String tin;
    private String taxpayerName;
    private String address;

    public Taxpayer(int id, String cDate, String uDate,
                    String tin, String name, String address) throws TaxDataException {
        super(id, cDate, uDate);

        if (tin.length() != 9) throw new TaxDataException("TIN must be 9 digits");
        if (name.isEmpty() || address.isEmpty()) throw new TaxDataException("Fields cannot be empty");

        this.tin = tin;
        this.taxpayerName = name;
        this.address = address;
    }

    public String getTin() { return tin; }
}
