package _27571.Q3;


public final class TaxRecord extends Entity {
    private String receiptNo;
    private double totalTax;
    private Employee employee;
    private TaxCategory category;

    public TaxRecord(int id, String cd, String ud,
                     String receiptNo, Employee emp, TaxCategory cat) throws TaxDataException {
        super(id, cd, ud);

        this.receiptNo = receiptNo;
        this.employee = emp;
        this.category = cat;
    }

    public double computeTax(double credits) {
        double tax = (employee.getSalary() * category.getRate()) - credits;
        this.totalTax = Math.max(tax, 0); // no negative tax
        return totalTax;
    }

    public double getTotalTax() { return totalTax; }
}

