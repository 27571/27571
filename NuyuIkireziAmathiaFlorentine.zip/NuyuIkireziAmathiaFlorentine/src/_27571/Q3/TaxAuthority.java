package _27571.Q3;

public class TaxAuthority extends Entity {
    private String authorityName;
    private String region;
    private String email;

    public TaxAuthority(int id, String createdDate, String updatedDate,
                        String name, String region, String email) throws TaxDataException {
        super(id, createdDate, updatedDate);

        if (!email.contains("@"))
            throw new TaxDataException("Invalid email");

        this.authorityName = name;
        this.region = region;
        this.email = email;
    }

    public String getAuthorityName() { return authorityName; }
}

