package _27571.Q3;


public class Employer extends Entity {
    private String employerName;
    private String employerTIN;
    private String contact;

    public Employer(int id, String cd, String ud,
                    String name, String tin, String contact) throws TaxDataException {
        super(id, cd, ud);

        if (tin.length() != 9) throw new TaxDataException("Employer TIN invalid");
        if (contact.length() != 10) throw new TaxDataException("Phone must be 10 digits");

        this.employerName = name;
        this.employerTIN = tin;
        this.contact = contact;
    }

    public String getEmployerTIN() { return employerTIN; }
}
