package _27571.Q3;


public class TaxCategory extends Entity {
    private String categoryName;
    private double rate;
    private String code;

    public TaxCategory(int id, String cDate, String uDate,
                       String name, double rate, String code) throws TaxDataException {
        super(id, cDate, uDate);

        if (rate <= 0) throw new TaxDataException("Rate must be > 0");
        if (code.length() < 3) throw new TaxDataException("Code must be ≥ 3 chars");

        this.categoryName = name;
        this.rate = rate;
        this.code = code;
    }

    public double getRate() { return rate; }
}

