package _27571.Q2;

public class Passenger extends Entity {
    private String passengerName;
    private int age;
    private String gender;
    private String contact;

    public Passenger(int id, String cd, String ud, String name, int age, String gender, String contact) {
        super(id, cd, ud);
        if (age <= 0) throw new IllegalArgumentException("Age must be > 0 (27571)");
        if (!gender.equalsIgnoreCase("Male") &&
                !gender.equalsIgnoreCase("Female"))
            throw new IllegalArgumentException("Invalid gender (27571)");

        this.passengerName = name;
        this.age = age;
        this.gender = gender;
        this.contact = contact;
    }

    public String getPassengerName() { return passengerName; }
}

