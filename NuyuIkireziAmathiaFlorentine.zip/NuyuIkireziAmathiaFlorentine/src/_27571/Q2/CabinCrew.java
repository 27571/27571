package _27571.Q2;

public class CabinCrew extends Entity {
    private String crewName;
    private String role;
    private String shift;

    public CabinCrew(int id, String cd, String ud, String crewName, String role, String shift) {
        super(id, cd, ud);
        if (role.isEmpty())
            throw new IllegalArgumentException("Role cannot be empty (27571)");
        if (!shift.equalsIgnoreCase("Day") && !shift.equalsIgnoreCase("Night"))
            throw new IllegalArgumentException("Shift must be Day or Night (27571)");

        this.crewName = crewName;
        this.role = role;
        this.shift = shift;
    }
}

