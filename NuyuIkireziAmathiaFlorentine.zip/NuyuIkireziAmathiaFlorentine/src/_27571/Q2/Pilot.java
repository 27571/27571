package _27571.Q2;



public class Pilot extends Entity {
    private String pilotName;
    private String licenseNumber;
    private int experienceYears;

    public Pilot(int id, String cd, String ud, String name, String license, int years) {
        super(id, cd, ud);
        if (license.isEmpty())
            throw new IllegalArgumentException("License cannot be empty (27571)");
        if (years < 2)
            throw new IllegalArgumentException("Experience must be ≥ 2 years (27571)");

        this.pilotName = name;
        this.licenseNumber = license;
        this.experienceYears = years;
    }
}

