package _27571.Q2;

public class Booking extends Entity {
    private String bookingDate;
    private String seatNumber;
    private String travelClass;

    public Booking(int id, String cd, String ud, String bookingDate,
                   String seatNumber, String travelClass) {
        super(id, cd, ud);

        if (!travelClass.equalsIgnoreCase("Economy") &&
                !travelClass.equalsIgnoreCase("Business") &&
                !travelClass.equalsIgnoreCase("First"))
            throw new IllegalArgumentException("Invalid travel class (27571)");

        this.bookingDate = bookingDate;
        this.seatNumber = seatNumber;
        this.travelClass = travelClass;
    }

    public String getTravelClass() { return travelClass; }
}

