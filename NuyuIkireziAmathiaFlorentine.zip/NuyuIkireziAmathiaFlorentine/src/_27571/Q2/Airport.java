package _27571.Q2;



public class Airport extends Entity {
    private String airportName;
    private String code;
    private String location;

    public Airport(int id, String cd, String ud, String airportName, String code, String location) {
        super(id, cd, ud);
        if (code.length() != 3 || !code.equals(code.toUpperCase()))
            throw new IllegalArgumentException("Airport code must be 3 uppercase letters (27571)");

        this.airportName = airportName;
        this.code = code;
        this.location = location;
    }

    public String getAirportName() { return airportName; }
    public String getCode() { return code; }
    public String getLocation() { return location; }
}

