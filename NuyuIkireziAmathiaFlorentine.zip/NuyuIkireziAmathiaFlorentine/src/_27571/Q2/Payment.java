package _27571.Q2;


public class Payment extends Entity {
    private String paymentDate;
    private String paymentMethod;
    private double amountPaid;

    public Payment(int id, String cd, String ud, String pd, String method, double amount) {
        super(id, cd, ud);
        if (amount <= 0)
            throw new IllegalArgumentException("Amount must be > 0 (27571)");
        if (method.isEmpty())
            throw new IllegalArgumentException("Payment method cannot be empty (27571)");

        this.paymentDate = pd;
        this.paymentMethod = method;
        this.amountPaid = amount;
    }

    public double getAmountPaid() { return amountPaid; }
}

