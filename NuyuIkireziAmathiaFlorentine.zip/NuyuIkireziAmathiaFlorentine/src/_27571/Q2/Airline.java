package _27571.Q2;



public class Airline extends Entity {
    private String airlineName;
    private String airlineCode;
    private String contactEmail;

    public Airline(int id, String cd, String ud, String airlineName, String airlineCode, String email) {
        super(id, cd, ud);
        if (airlineCode.length() < 2 || airlineCode.length() > 4)
            throw new IllegalArgumentException("Airline code must be 2–4 letters (27571)");
        if (!email.contains("@"))
            throw new IllegalArgumentException("Invalid email (27571)");

        this.airlineName = airlineName;
        this.airlineCode = airlineCode;
        this.contactEmail = email;
    }

    public String getAirlineName() { return airlineName; }
    public String getAirlineCode() { return airlineCode; }
    public String getContactEmail() { return contactEmail; }
}

