package _27571.Q2;

import java.util.Scanner;

public class MainBooking {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("===== FLIGHT BOOKING SYSTEM (27571) =====");

        // --- PASSENGER INPUT ---
        System.out.print("Passenger Name: ");
        String name = sc.nextLine();

        System.out.print("Age: ");
        int age = sc.nextInt(); sc.nextLine();

        System.out.print("Gender (Male/Female): ");
        String gender = sc.nextLine();

        System.out.print("Contact: ");
        String contact = sc.nextLine();

        Passenger pass = new Passenger(1, "2025-01-01", "2025-01-01",
                name, age, gender, contact);

        // --- FLIGHT ---
        Flight flight = new Flight(2, "2025-01-01", "2025-01-01",
                "WK123", "KGL", "NBO", 150000);

        // --- BOOKING ---
        System.out.print("Booking Date: ");
        String bdate = sc.nextLine();

        System.out.print("Seat Number: ");
        String seat = sc.nextLine();

        System.out.print("Travel Class (Economy/Business/First): ");
        String tclass = sc.nextLine();

        Booking booking = new Booking(3, "2025-01-01", "2025-01-01",
                bdate, seat, tclass);

        // --- PAYMENT ---
        System.out.print("Payment Method: ");
        String method = sc.nextLine();

        System.out.print("Amount Paid: ");
        double amount = sc.nextDouble();

        Payment pay = new Payment(4, "2025-01-01", "2025-01-01",
                "2025-01-05", method, amount);

        // --- TICKET ---
        Ticket ticket = new Ticket(5, "2025-01-01", "2025-01-01",
                "TCK27571", "2025-01-06",
                flight, booking, pay);

        ticket.calculateFare();

        System.out.println("\n--- END OF BOOKING REPORT (27571) ---");
    }
}

