package _27571.Q2;


public final class Ticket extends Entity {
    private String ticketNumber;
    private String issueDate;
    private Flight flight;
    private Booking booking;
    private Payment payment;

    public Ticket(int id, String cd, String ud, String ticketNumber, String issueDate,
                  Flight flight, Booking booking, Payment payment) {
        super(id, cd, ud);
        this.ticketNumber = ticketNumber;
        this.issueDate = issueDate;
        this.flight = flight;
        this.booking = booking;
        this.payment = payment;
    }

    public void calculateFare() {
        System.out.println("\n----- TICKET SUMMARY (27571) -----");

        double base = flight.getBaseFare();
        double taxes = base * 0.18;        // 18% VAT
        double discount = booking.getTravelClass().equalsIgnoreCase("Business") ? 50 :
                booking.getTravelClass().equalsIgnoreCase("First") ? 100 : 0;

        double finalFare = base + taxes - discount;

        System.out.println("Base Fare: " + base + " (27571)");
        System.out.println("Taxes (18%): " + taxes + " (27571)");
        System.out.println("Discount: " + discount + " (27571)");
        System.out.println("Final Fare: " + finalFare + " (27571)");
    }
}

