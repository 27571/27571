package _27571.Q2;


public class Flight extends Entity {
    private String flightNumber;
    private String departure;
    private String destination;
    private double baseFare;

    public Flight(int id, String cd, String ud, String flightNumber, String departure,
                  String destination, double baseFare) {
        super(id, cd, ud);
        if (baseFare <= 0) throw new IllegalArgumentException("Base fare must be > 0 (27571)");

        this.flightNumber = flightNumber;
        this.departure = departure;
        this.destination = destination;
        this.baseFare = baseFare;
    }

    public double getBaseFare() { return baseFare; }
    public String getFlightNumber() { return flightNumber; }
}

