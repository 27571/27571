package _27571.Q1;

import java.util.*;
class Supplier extends Category {
    private String supplierName;
    private String supplierEmail;
    private String supplierPhone;


    public Supplier(int id, String warehouseName, String location, String contactNumber,
                    String categoryName, String categoryCode,
                    String supplierName, String supplierEmail, String supplierPhone) {
        super(id, warehouseName, location, contactNumber, categoryName, categoryCode);


        if (!supplierEmail.contains("@"))
            throw new IllegalArgumentException("Invalid supplier email");


        if (!supplierPhone.matches("\\d{10}"))
            throw new IllegalArgumentException("Phone must be 10 digits");


        this.supplierName = supplierName;
        this.supplierEmail = supplierEmail;
        this.supplierPhone = supplierPhone;
    }
}
