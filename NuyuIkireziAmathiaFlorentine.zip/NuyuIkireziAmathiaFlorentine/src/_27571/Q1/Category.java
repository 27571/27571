package _27571.Q1;
import java.util.*;

class Category extends Warehouse {
    private String categoryName;
    private String categoryCode;


    public Category(int id, String warehouseName, String location, String contactNumber,
                    String categoryName, String categoryCode) {
        super(id, warehouseName, location, contactNumber);


        if (categoryCode.length() < 3 || !categoryCode.matches("[A-Za-z0-9]+"))
            throw new IllegalArgumentException("Code must be alphanumeric and >= 3 chars");


        this.categoryName = categoryName;
        this.categoryCode = categoryCode;
    }
}