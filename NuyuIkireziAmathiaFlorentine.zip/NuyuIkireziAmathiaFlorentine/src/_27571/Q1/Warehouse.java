package _27571.Q1;
import java.util.*;

class Warehouse extends Entity {
    private String warehouseName;
    private String location;
    private String contactNumber;


    public Warehouse(int id, String warehouseName, String location, String contactNumber) {
        super(id);
        this.warehouseName = warehouseName;
        this.location = location;


        if (!contactNumber.matches("\\d{10}"))
            throw new IllegalArgumentException("Contact number must be 10 digits");


        this.contactNumber = contactNumber;
    }
}
