package _27571.Q1;

import java.util.Date;

class Purchase extends StockItem {
    private Date purchaseDate;
    private int purchasedQuantity;
    private String supplierName;


    public Purchase(int id, String warehouseName, String location, String contactNumber,
                    String categoryName, String categoryCode,
                    String supplierName, String supplierEmail, String supplierPhone,
                    String productName, double unitPrice, int stockLimit,
                    int quantityAvailable, int reorderLevel,
                    int purchasedQuantity, Date purchaseDate) {


        super(id, warehouseName, location, contactNumber, categoryName, categoryCode,
                supplierName, supplierEmail, supplierPhone,
                productName, unitPrice, stockLimit,
                quantityAvailable, reorderLevel);


        if (purchasedQuantity <= 0)
            throw new IllegalArgumentException("Purchased quantity > 0");


        if (purchaseDate == null) throw new IllegalArgumentException("Purchase date invalid");


        this.purchasedQuantity = purchasedQuantity;
        this.purchaseDate = purchaseDate;
        this.supplierName = supplierName;
    }
}
