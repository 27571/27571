package _27571.Q1;

import java.util.Date;

class Inventory extends Sale {
    private int totalItems;
    private double stockValue;


    public Inventory(int id, String warehouseName, String location, String contactNumber,
                     String categoryName, String categoryCode,
                     String supplierName, String supplierEmail, String supplierPhone,
                     String productName, double unitPrice, int stockLimit,
                     int quantityAvailable, int reorderLevel,
                     int purchasedQuantity, Date purchaseDate,
                     int soldQuantity, Date saleDate, String customerName,
                     int totalItems, double stockValue) {


        super(id, warehouseName, location, contactNumber, categoryName, categoryCode,
                supplierName, supplierEmail, supplierPhone,
                productName, unitPrice, stockLimit,
                quantityAvailable, reorderLevel,
                purchasedQuantity, purchaseDate,
                soldQuantity, saleDate, customerName);


        if (totalItems < 0 || stockValue < 0)
            throw new IllegalArgumentException("Totals must be >= 0");


        this.totalItems = totalItems;
        this.stockValue = stockValue;
    }


    public int getTotalItems() { return totalItems; }
    public double getStockValue() { return stockValue; }
}
