package _27571.Q1;

class StockItem extends Product {
    private int quantityAvailable;
    private int reorderLevel;


    public StockItem(int id, String warehouseName, String location, String contactNumber,
                     String categoryName, String categoryCode,
                     String supplierName, String supplierEmail, String supplierPhone,
                     String productName, double unitPrice, int stockLimit,
                     int quantityAvailable, int reorderLevel) {


        super(id, warehouseName, location, contactNumber, categoryName, categoryCode,
                supplierName, supplierEmail, supplierPhone,
                productName, unitPrice, stockLimit);


        if (quantityAvailable < 0 || reorderLevel < 0)
            throw new IllegalArgumentException("Values must be >= 0");


        this.quantityAvailable = quantityAvailable;
        this.reorderLevel = reorderLevel;
    }
}
