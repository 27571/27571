package _27571.Q1;

class Product extends Supplier {
    private String productName;
    private double unitPrice;
    private int stockLimit;


    public Product(int id, String warehouseName, String location, String contactNumber,
                   String categoryName, String categoryCode,
                   String supplierName, String supplierEmail, String supplierPhone,
                   String productName, double unitPrice, int stockLimit) {


        super(id, warehouseName, location, contactNumber, categoryName, categoryCode,
                supplierName, supplierEmail, supplierPhone);


        if (unitPrice <= 0) throw new IllegalArgumentException("Price must be > 0");
        if (stockLimit < 0) throw new IllegalArgumentException("Stock limit >= 0");


        this.productName = productName;
        this.unitPrice = unitPrice;
        this.stockLimit = stockLimit;
    }
}
