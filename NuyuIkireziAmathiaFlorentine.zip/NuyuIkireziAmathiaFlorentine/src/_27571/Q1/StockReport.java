package _27571.Q1;

import java.util.Date;

final class StockReport extends Inventory {
    private String reportDate;
    private String remarks;


    public StockReport(int id, String warehouseName, String location, String contactNumber,
                       String categoryName, String categoryCode,
                       String supplierName, String supplierEmail, String supplierPhone,
                       String productName, double unitPrice, int stockLimit,
                       int quantityAvailable, int reorderLevel,
                       int purchasedQuantity, Date purchaseDate,
                       int soldQuantity, Date saleDate, String customerName,
                       int totalItems, double stockValue,
                       String reportDate, String remarks) {


        super(id, warehouseName, location, contactNumber, categoryName, categoryCode,
                supplierName, supplierEmail, supplierPhone,
                productName, unitPrice, stockLimit,
                quantityAvailable, reorderLevel,
                purchasedQuantity, purchaseDate,
                soldQuantity, saleDate, customerName,
                totalItems, stockValue);


        this.reportDate = reportDate;
        this.remarks = remarks;
    }


    public void generateReport() {
        System.out.println("\n===== STOCK REPORT =====");
        System.out.println("Report Date: " + reportDate);
        System.out.println("Total Items: " + getTotalItems());
        System.out.println("Stock Value: " + getStockValue());
        System.out.println("Remarks: " + remarks);
    }
}
