package _27571.Q1;

import java.util.Date;

class Sale extends Purchase {
    private Date saleDate;
    private int soldQuantity;
    private String customerName;


    public Sale(int id, String warehouseName, String location, String contactNumber,
                String categoryName, String categoryCode,
                String supplierName, String supplierEmail, String supplierPhone,
                String productName, double unitPrice, int stockLimit,
                int quantityAvailable, int reorderLevel,
                int purchasedQuantity, Date purchaseDate,
                int soldQuantity, Date saleDate, String customerName) {


        super(id, warehouseName, location, contactNumber, categoryName, categoryCode,
                supplierName, supplierEmail, supplierPhone,
                productName, unitPrice, stockLimit,
                quantityAvailable, reorderLevel,
                purchasedQuantity, purchaseDate);


        if (soldQuantity <= 0)
            throw new IllegalArgumentException("Sold quantity must be > 0");


        this.soldQuantity = soldQuantity;
        this.saleDate = saleDate;
        this.customerName = customerName;
    }
}
